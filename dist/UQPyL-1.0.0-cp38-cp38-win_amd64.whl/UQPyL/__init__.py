from . import problems, surrogates, optimization

__version__ = "0.3.3"
__author__ = "wmtSky"

__all__=[
    "problems",
    "surrogates",
    "optimization"
]